import  { FAQ, Event, Testimonial, LeaderboardUser, Location, Course } from '../types';

export const faqs: FAQ[] = [
  {
    question: "How do I access SRM's WiFi?",
    answer: "You can use your student ID as the username and your DOB in DDMMYYYY format as the password to connect to SRM_STUDENT network."
  },
  {
    question: "When are semester exams usually held?",
    answer: "Mid-semester exams are typically held in late September and late February, while end-semester exams are held in December and May."
  },
  {
    question: "How do I access the digital library resources?",
    answer: "Login to the SRM Library portal using your student credentials. You can access e-journals, e-books, and research papers from anywhere."
  },
  {
    question: "What is the attendance requirement to write exams?",
    answer: "You need a minimum of 75% attendance in each course to be eligible to write the semester examinations."
  },
  {
    question: "How do I apply for hostel accommodation?",
    answer: "You can apply for hostel accommodation through the SRM Student Portal. Select 'Hostel Services' and follow the instructions."
  }
];

export const events: Event[] = [
  {
    id: 1,
    title: "Tech Symposium 2023",
    date: "2023-11-20",
    location: "Main Auditorium",
    description: "Annual tech fest featuring coding competitions, project showcases, and industry speakers.",
    image: "https://images.unsplash.com/photo-1543193158-07c01963e800?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwxfHxzcmklMjByYW1hY2hhbmRyYSUyMHVuaXZlcnNpdHklMjBjYW1wdXN8ZW58MHx8fHwxNzQ0NzM5MTI5fDA&ixlib=rb-4.0.3&fit=fillmax&h=600&w=800"
  },
  {
    id: 2,
    title: "Cultural Festival: Rhythms 2023",
    date: "2023-12-05",
    location: "Open Air Theatre",
    description: "Celebrate diversity through music, dance, and various cultural performances.",
    image: "https://images.unsplash.com/photo-1519452575417-564c1401ecc0?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwzfHxzcmklMjByYW1hY2hhbmRyYSUyMHVuaXZlcnNpdHklMjBjYW1wdXN8ZW58MHx8fHwxNzQ0NzM5MTI5fDA&ixlib=rb-4.0.3&fit=fillmax&h=600&w=800"
  },
  {
    id: 3,
    title: "Alumni Meet",
    date: "2023-12-15",
    location: "Convention Center",
    description: "Connect with SRM alumni and learn about their experiences and career paths.",
    image: "https://images.unsplash.com/20/cambridge.JPG?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwyfHxzcmklMjByYW1hY2hhbmRyYSUyMHVuaXZlcnNpdHklMjBjYW1wdXN8ZW58MHx8fHwxNzQ0NzM5MTI5fDA&ixlib=rb-4.0.3&fit=fillmax&h=600&w=800"
  }
];

export const testimonials: Testimonial[] = [
  {
    id: 1,
    name: "Rahul Sharma",
    program: "B.Tech Computer Science",
    year: "3rd Year",
    message: "CampusPal has been a game-changer for me. It helped me navigate campus events and find study resources quickly!"
  },
  {
    id: 2,
    name: "Priya Patel",
    program: "MBA",
    year: "1st Year",
    message: "As a new student, CampusPal made my transition to SRM so much easier. The chatbot answered all my questions instantly."
  },
  {
    id: 3,
    name: "Arun Kumar",
    program: "B.Tech Electronics",
    year: "Final Year",
    message: "The event notifications and exam schedule reminders have saved me multiple times. Highly recommend for all SRM students!"
  }
];

export const leaderboard: LeaderboardUser[] = [
  {
    id: 1,
    name: "Akshay Mehta",
    points: 850,
    rank: 1
  },
  {
    id: 2,
    name: "Sneha Reddy",
    points: 720,
    rank: 2
  },
  {
    id: 3,
    name: "Vikram Singh",
    points: 695,
    rank: 3
  },
  {
    id: 4,
    name: "Neha Gupta",
    points: 560,
    rank: 4
  },
  {
    id: 5,
    name: "Rohan Joshi",
    points: 525,
    rank: 5
  }
];

export const locations: Location[] = [
  {
    id: "lib",
    name: "University Library",
    description: "The central library with 5 floors of books, journals, and study spaces.",
    directions: "Located near the main entrance, opposite to the administrative block."
  },
  {
    id: "admin",
    name: "Administrative Block",
    description: "Houses the Admissions Office, Finance Department, and Registrar's Office.",
    directions: "Enter through the main gate and turn right. It's the first major building."
  },
  {
    id: "hostel",
    name: "Student Hostels",
    description: "Multiple hostel blocks for male and female students with modern amenities.",
    directions: "Located on the east side of campus, behind the sports complex."
  },
  {
    id: "cafe",
    name: "University Cafeteria",
    description: "Multiple food outlets serving various cuisines throughout the day.",
    directions: "Central location, near the sports complex and main quadrangle."
  },
  {
    id: "sports",
    name: "Sports Complex",
    description: "Includes indoor and outdoor facilities for various sports and fitness activities.",
    directions: "Located behind the main academic blocks, next to the open air theater."
  }
];

export const courses: Course[] = [
  {
    id: "cs101",
    name: "Introduction to Computer Science",
    code: "CS101",
    schedule: [
      { day: "Monday", time: "10:00 AM - 11:30 AM", room: "Tech Block, Room 201" },
      { day: "Wednesday", time: "10:00 AM - 11:30 AM", room: "Tech Block, Room 201" }
    ]
  },
  {
    id: "math102",
    name: "Engineering Mathematics",
    code: "MATH102",
    schedule: [
      { day: "Tuesday", time: "9:00 AM - 10:30 AM", room: "Main Block, Room 105" },
      { day: "Thursday", time: "9:00 AM - 10:30 AM", room: "Main Block, Room 105" }
    ]
  },
  {
    id: "phy103",
    name: "Engineering Physics",
    code: "PHY103",
    schedule: [
      { day: "Monday", time: "2:00 PM - 3:30 PM", room: "Science Block, Room 302" },
      { day: "Friday", time: "11:00 AM - 12:30 PM", room: "Science Block, Lab 2" }
    ]
  }
];

export const wifiPassword = "SRM_Campus@2023";

export const funFacts = [
  "SRM University was established in 1985 as SRM Engineering College and gained university status in 2002.",
  "The SRM campus spans over 250 acres with state-of-the-art facilities.",
  "SRM has partnerships with over 150 international universities for exchange programs.",
  "The university's Tech Park houses several international companies for internship opportunities.",
  "SRM's library has over 100,000 books and access to more than 5,000 e-journals.",
  "The university has its own FM radio station run by students.",
  "SRM's sports complex includes an Olympic-sized swimming pool.",
  "The university has students from over 55 different countries.",
  "SRM has launched its own satellite in collaboration with ISRO.",
  "The university hosts one of the largest technical festivals in South India called 'Aaruush'."
];

export const generalResponses = {
  greeting: "Hello! Welcome to CampusPal. How can I assist you with SRM University today?",
  fallback: "I'm sorry, I didn't understand that. Could you rephrase your question about SRM University?",
  thanks: "You're welcome! If you have any more questions about SRM University, feel free to ask.",
  goodbye: "Goodbye! Have a great day on campus!"
};

export const chatbotResponses = {
  "wifi password": "The SRM WiFi password is SRM_Campus@2023. Use your student ID as the username.",
  "library": "The university library is located near the main entrance, opposite to the administrative block. It's open from 8 AM to 10 PM on weekdays.",
  "exam schedule": "The mid-semester exams are scheduled for the last week of September, and end-semester exams will begin in the first week of December.",
  "hostel": "SRM has separate hostel facilities for boys and girls with various accommodation options. You can apply through the SRM Student Portal.",
  "canteen": "The main cafeteria is located at the center of the campus. There are also several food courts near each academic block.",
  "admission": "For admission inquiries, please visit the Admissions Office in the Administrative Block or check the university website.",
  "courses": "SRM offers various undergraduate and postgraduate programs across Engineering, Medicine, Science, Humanities, and Management.",
  "events": "You can check the Events section in CampusPal for upcoming events on campus.",
  "sports": "The sports complex includes facilities for cricket, football, basketball, tennis, swimming, and a well-equipped gymnasium.",
  "contact": "You can contact the university at info@srmuniversity.ac.in or call the helpline at 1800-123-4567."
};
 
export  interface FAQ {
  question: string;
  answer: string;
}

export interface Event {
  id: number;
  title: string;
  date: string;
  location: string;
  description: string;
  image?: string;
}

export interface Testimonial {
  id: number;
  name: string;
  program: string;
  year: string;
  message: string;
  avatar?: string;
}

export interface LeaderboardUser {
  id: number;
  name: string;
  points: number;
  rank: number;
  avatar?: string;
}

export interface ChatMessage {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
}

export interface Location {
  id: string;
  name: string;
  description: string;
  directions: string;
}

export interface Course {
  id: string;
  name: string;
  code: string;
  schedule: {
    day: string;
    time: string;
    room: string;
  }[];
}
 
import  { v4 as uuidv4 } from 'uuid';
import { ChatMessage } from '../types';
import { chatbotResponses, generalResponses, funFacts, wifiPassword } from '../data';

export const generateChatbotResponse = (message: string): Promise<string> => {
  return new Promise((resolve) => {
    // Normalize message for matching
    const normalizedMessage = message.toLowerCase().trim();
    
    // Check for specific keyword matches first
    for (const [keyword, response] of Object.entries(chatbotResponses)) {
      if (normalizedMessage.includes(keyword)) {
        return setTimeout(() => resolve(response), 500);
      }
    }
    
    // Handle greetings
    if (
      normalizedMessage.includes('hi') || 
      normalizedMessage.includes('hello') || 
      normalizedMessage.includes('hey')
    ) {
      return setTimeout(() => resolve(generalResponses.greeting), 500);
    }
    
    // Handle thanks/appreciation
    if (
      normalizedMessage.includes('thank') || 
      normalizedMessage.includes('thanks') || 
      normalizedMessage.includes('appreciate')
    ) {
      return setTimeout(() => resolve(generalResponses.thanks), 500);
    }
    
    // Handle goodbyes
    if (
      normalizedMessage.includes('bye') || 
      normalizedMessage.includes('goodbye') || 
      normalizedMessage.includes('see you')
    ) {
      return setTimeout(() => resolve(generalResponses.goodbye), 500);
    }
    
    // Handle WiFi password specifically
    if (
      normalizedMessage.includes('wifi') && 
      normalizedMessage.includes('password')
    ) {
      return setTimeout(() => resolve(`The SRM WiFi password is ${wifiPassword}. Use your student ID as the username.`), 500);
    }
    
    // Handle fun facts
    if (normalizedMessage.includes('fact') || normalizedMessage.includes('tell me something')) {
      const randomFact = funFacts[Math.floor(Math.random() * funFacts.length)];
      return setTimeout(() => resolve(`Did you know? ${randomFact}`), 500);
    }
    
    // Handle fallback
    setTimeout(() => resolve(generalResponses.fallback), 500);
  });
};

export const createChatMessage = (text: string, isUser: boolean): ChatMessage => {
  return {
    id: uuidv4(),
    text,
    isUser,
    timestamp: new Date()
  };
};
 
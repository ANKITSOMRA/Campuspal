import  { useEffect } from 'react';
import Navbar from '../components/Navbar';
import HeroSection from '../components/HeroSection';
import Features from '../components/Features';
import HowItWorks from '../components/HowItWorks';
import TestimonialsSection from '../components/TestimonialsSection';
import EventsSection from '../components/EventsSection';
import FaqSection from '../components/FaqSection';
import LeaderboardSection from '../components/LeaderboardSection';
import ContactSection from '../components/ContactSection';
import Footer from '../components/Footer';
import ChatbotBubble from '../components/ChatbotBubble';
import { initScrollAnimations } from '../utils/animations';

const LandingPage = () => {
  useEffect(() => {
    initScrollAnimations();
    
    // Ensure animations trigger when navigating to this page
    const fadeElements = document.querySelectorAll('.fade-in');
    fadeElements.forEach(element => {
      setTimeout(() => {
        element.classList.add('visible');
      }, 300);
    });
  }, []);

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow">
        <HeroSection />
        <Features />
        <HowItWorks />
        <TestimonialsSection />
        <EventsSection />
        <LeaderboardSection />
        <FaqSection />
        <ContactSection />
      </main>
      <Footer />
      <ChatbotBubble />
    </div>
  );
};

export default LandingPage;
 
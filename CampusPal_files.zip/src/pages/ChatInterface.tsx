import  { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Info, ChevronLeft } from 'lucide-react';
import ChatHeader from '../components/Chat/ChatHeader';
import MessageList from '../components/Chat/MessageList';
import MessageInput from '../components/Chat/MessageInput';
import QuickReplies from '../components/Chat/QuickReplies';
import SidePanel from '../components/Chat/SidePanel';
import { ChatMessage } from '../types';
import { generateChatbotResponse, createChatMessage } from '../utils/chatbot';

const ChatInterface = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [sidePanelOpen, setSidePanelOpen] = useState(false);
  const location = useLocation();
  const initialMessage = location.state?.initialMessage || '';

  useEffect(() => {
    // Add initial greeting message
    const welcomeMessage = createChatMessage(
      "Hello! I'm your SRM University assistant. How can I help you today?",
      false
    );
    
    setMessages([welcomeMessage]);
    
    // If there's an initial message from the homepage quick chat, process it
    if (initialMessage) {
      handleSendMessage(initialMessage);
    }
  }, []);

  const handleSendMessage = async (text: string) => {
    // Add user message to the chat
    const userMessage = createChatMessage(text, true);
    setMessages((prevMessages) => [...prevMessages, userMessage]);
    
    // Show typing indicator
    setLoading(true);
    
    try {
      // Generate chatbot response
      const responseText = await generateChatbotResponse(text);
      
      // Add chatbot response to the chat
      const botMessage = createChatMessage(responseText, false);
      setMessages((prevMessages) => [...prevMessages, botMessage]);
    } catch (error) {
      console.error('Error generating response:', error);
      
      // Add error message
      const errorMessage = createChatMessage(
        "I'm sorry, I'm having trouble processing your request right now. Please try again later.",
        false
      );
      setMessages((prevMessages) => [...prevMessages, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  const handleQuickReply = (reply: string) => {
    handleSendMessage(reply);
  };

  return (
    <div className="flex flex-col h-screen bg-white">
      <ChatHeader />
      
      <div className="flex-1 flex flex-col overflow-hidden relative">
        <MessageList messages={messages} />
        
        <button
          onClick={() => setSidePanelOpen(true)}
          className="absolute top-4 right-4 bg-white p-2 rounded-full shadow-md hover:bg-gray-100"
          aria-label="Open resources panel"
        >
          <Info className="h-5 w-5 text-primary" />
        </button>
        
        <SidePanel 
          isOpen={sidePanelOpen} 
          onClose={() => setSidePanelOpen(false)} 
        />
        
        <QuickReplies onSelectReply={handleQuickReply} />
        <MessageInput onSendMessage={handleSendMessage} disabled={loading} />
      </div>
    </div>
  );
};

export default ChatInterface;
 
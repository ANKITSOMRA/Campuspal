import  { useState, useRef } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Phone, ChevronLeft, ChevronRight, Lock } from 'lucide-react';

const Login = () => {
  const [step, setStep] = useState(1);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otp, setOtp] = useState(['', '', '', '']);
  const [phoneError, setPhoneError] = useState('');
  const [otpError, setOtpError] = useState('');
  const [loading, setLoading] = useState(false);
  const otpInputRefs = useRef<(HTMLInputElement | null)[]>([]);
  const navigate = useNavigate();

  const validatePhoneNumber = (phone: string) => {
    const regex = /^[6-9]\d{9}$/; // Indian mobile number validation
    return regex.test(phone);
  };

  const handlePhoneNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '');
    setPhoneNumber(value);
    setPhoneError('');
  };

  const handleRequestOTP = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validatePhoneNumber(phoneNumber)) {
      setPhoneError('Please enter a valid 10-digit mobile number');
      return;
    }
    
    setLoading(true);
    
    // Simulate OTP sending
    setTimeout(() => {
      setLoading(false);
      setStep(2);
      // Focus the first OTP input field
      if (otpInputRefs.current[0]) {
        otpInputRefs.current[0].focus();
      }
    }, 1500);
  };

  const handleOtpChange = (index: number, value: string) => {
    // Only allow digits
    value = value.replace(/\D/g, '');
    
    // Update the OTP array
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);
    setOtpError('');
    
    // Auto-focus next input
    if (value && index < 3 && otpInputRefs.current[index + 1]) {
      otpInputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    // Move to previous input on backspace if current input is empty
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      otpInputRefs.current[index - 1]?.focus();
    }
    
    // Handle paste events
    if (e.key === 'v' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      
      navigator.clipboard.readText().then(text => {
        const digits = text.replace(/\D/g, '').slice(0, 4).split('');
        
        const newOtp = [...otp];
        digits.forEach((digit, i) => {
          if (i < 4) {
            newOtp[i] = digit;
          }
        });
        
        setOtp(newOtp);
        
        // Focus last filled input or the next empty one
        const lastIndex = Math.min(digits.length, 3);
        otpInputRefs.current[lastIndex]?.focus();
      });
    }
  };

  const handleVerifyOTP = (e: React.FormEvent) => {
    e.preventDefault();
    
    const otpValue = otp.join('');
    
    if (otpValue.length !== 4) {
      setOtpError('Please enter a valid 4-digit OTP');
      return;
    }
    
    setLoading(true);
    
    // Simulate OTP verification (using 1234 as the valid OTP)
    setTimeout(() => {
      setLoading(false);
      
      if (otpValue === '1234') {
        navigate('/chat');
      } else {
        setOtpError('Invalid OTP. Please try again.');
      }
    }, 1500);
  };

  return (
    <div className="min-h-screen flex items-center justify-center animated-gradient">
      <div className="w-full max-w-md mx-4">
        <div className="card p-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-800">CampusPal</h2>
            <p className="text-gray-600 mt-2">Your SRM University Assistant</p>
          </div>
          
          {step === 1 ? (
            <>
              <h3 className="text-xl font-semibold mb-6 text-center">Login with Your Phone</h3>
              
              <form onSubmit={handleRequestOTP}>
                <div className="mb-6">
                  <label htmlFor="phone" className="block text-gray-700 font-medium mb-2">
                    Phone Number
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                      <Phone className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      type="tel"
                      id="phone"
                      maxLength={10}
                      className={`input-field pl-10 ${phoneError ? 'border-red-500' : ''}`}
                      placeholder="Enter your 10-digit mobile number"
                      value={phoneNumber}
                      onChange={handlePhoneNumberChange}
                    />
                  </div>
                  {phoneError && <p className="mt-2 text-sm text-red-600">{phoneError}</p>}
                </div>
                
                <button
                  type="submit"
                  className="btn btn-primary w-full flex items-center justify-center"
                  disabled={loading}
                >
                  {loading ? (
                    <span className="inline-block h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></span>
                  ) : null}
                  {loading ? 'Sending OTP...' : 'Request OTP'}
                  {!loading && <ChevronRight className="ml-2 h-5 w-5" />}
                </button>
              </form>
              
              <div className="mt-6 text-center">
                <p className="text-gray-600">
                  Note: Use any 10-digit number. <br />
                  For demo, OTP will be 1234.
                </p>
              </div>
            </>
          ) : (
            <>
              <button 
                onClick={() => setStep(1)} 
                className="flex items-center text-primary hover:text-primary-dark mb-6"
              >
                <ChevronLeft className="h-5 w-5 mr-1" />
                Back
              </button>
              
              <h3 className="text-xl font-semibold mb-6 text-center">Enter Verification Code</h3>
              
              <p className="text-gray-600 text-center mb-6">
                We've sent a 4-digit OTP to {phoneNumber}
              </p>
              
              <form onSubmit={handleVerifyOTP}>
                <div className="mb-6">
                  <label className="block text-gray-700 font-medium mb-2">
                    One-Time Password (OTP)
                  </label>
                  <div className="flex justify-center items-center gap-2">
                    {otp.map((digit, index) => (
                      <input
                        key={index}
                        type="text"
                        maxLength={1}
                        className={`otp-input ${otpError ? 'border-red-500' : ''}`}
                        value={digit}
                        onChange={(e) => handleOtpChange(index, e.target.value)}
                        onKeyDown={(e) => handleKeyDown(index, e)}
                        ref={el => otpInputRefs.current[index] = el}
                      />
                    ))}
                  </div>
                  {otpError && <p className="mt-2 text-sm text-red-600 text-center">{otpError}</p>}
                </div>
                
                <button
                  type="submit"
                  className="btn btn-primary w-full flex items-center justify-center"
                  disabled={loading}
                >
                  {loading ? (
                    <span className="inline-block h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></span>
                  ) : (
                    <Lock className="mr-2 h-5 w-5" />
                  )}
                  {loading ? 'Verifying...' : 'Verify OTP'}
                </button>
              </form>
              
              <div className="mt-6 text-center">
                <p className="text-gray-600">
                  Didn't receive the code?{' '}
                  <button 
                    className="text-primary hover:text-primary-dark font-medium"
                    onClick={() => {
                      setLoading(true);
                      setTimeout(() => {
                        setLoading(false);
                        setOtp(['', '', '', '']);
                        if (otpInputRefs.current[0]) {
                          otpInputRefs.current[0].focus();
                        }
                      }, 1500);
                    }}
                    disabled={loading}
                  >
                    Resend OTP
                  </button>
                </p>
              </div>
            </>
          )}
          
          <div className="mt-8 text-center">
            <Link to="/" className="text-primary hover:text-primary-dark font-medium">
              Return to Homepage
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
 
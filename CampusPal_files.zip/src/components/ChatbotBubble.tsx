import  { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MessageSquare, X } from 'lucide-react';

const ChatbotBubble = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      navigate('/chat', { state: { initialMessage: message } });
    }
  };

  return (
    <div className="fixed bottom-8 right-8 z-50">
      {isOpen ? (
        <div className="bg-white rounded-lg shadow-2xl w-80 transition-all duration-300 overflow-hidden">
          <div className="bg-primary p-4 flex justify-between items-center">
            <h3 className="text-white font-bold">CampusPal Assistant</h3>
            <button onClick={() => setIsOpen(false)} className="text-white">
              <X className="h-5 w-5" />
            </button>
          </div>
          <div className="p-4">
            <p className="text-gray-700 mb-4">
              Hi there! I can help you with information about SRM University. What would you like to know?
            </p>
            <form onSubmit={handleSubmit}>
              <div className="flex">
                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Type your question here..."
                  className="input-field flex-grow"
                />
                <button 
                  type="submit" 
                  className="ml-2 bg-primary text-white p-2 rounded-lg"
                >
                  <MessageSquare className="h-5 w-5" />
                </button>
              </div>
            </form>
            <div className="mt-4 text-center">
              <button 
                onClick={() => navigate('/chat')}
                className="text-primary hover:underline text-sm"
              >
                Open full chat
              </button>
            </div>
          </div>
        </div>
      ) : (
        <button 
          onClick={() => setIsOpen(true)}
          className="bg-primary hover:bg-primary-dark text-white rounded-full w-16 h-16 flex items-center justify-center shadow-lg pulse-glow transition-all duration-300 transform hover:scale-110"
        >
          <MessageSquare className="h-8 w-8" />
        </button>
      )}
    </div>
  );
};

export default ChatbotBubble;
 
import  { MessageSquare, CheckCircle, User } from 'lucide-react';

const HowItWorks = () => {
  const steps = [
    {
      icon: <User className="h-12 w-12 text-white" />,
      title: "Sign In",
      description: "Log in with your SRM student credentials or register using your student email and phone number."
    },
    {
      icon: <MessageSquare className="h-12 w-12 text-white" />,
      title: "Ask Questions",
      description: "Type your questions about campus, courses, events, or facilities to get instant answers."
    },
    {
      icon: <CheckCircle className="h-12 w-12 text-white" />,
      title: "Get Solutions",
      description: "Receive personalized responses, directions, schedules, and helpful resources for your SRM journey."
    }
  ];

  return (
    <section id="how-it-works" className="py-20 bg-primary text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">How CampusPal Works</h2>
          <p className="text-xl max-w-2xl mx-auto">
            Getting the information you need about SRM University has never been easier.
          </p>
        </div>
        
        <div className="flex flex-col md:flex-row gap-8 justify-center">
          {steps.map((step, index) => (
            <div 
              key={index}
              className="flex-1 text-center glassmorphism rounded-xl p-8 fade-in max-w-sm mx-auto"
            >
              <div className="mb-6 flex justify-center">
                {step.icon}
              </div>
              <h3 className="text-2xl font-bold mb-4">{step.title}</h3>
              <p>{step.description}</p>
              
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute right-0 top-1/2 transform -translate-y-1/2 translate-x-1/2">
                  <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
                  </svg>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
 
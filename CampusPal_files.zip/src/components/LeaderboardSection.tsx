import  { Trophy, Award, Star } from 'lucide-react';
import { leaderboard } from '../data';

const LeaderboardSection = () => {
  const topThree = leaderboard.slice(0, 3);
  const restOfList = leaderboard.slice(3);

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">Student Leaderboard</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Our most active students who contribute to campus events and activities.
          </p>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <div className="flex flex-col md:flex-row justify-center items-end mb-12 gap-6">
            {topThree.map((user, index) => {
              const rank = index + 1;
              let badgeIcon;
              let badgeColor;
              
              switch (rank) {
                case 1:
                  badgeIcon = <Trophy className="h-8 w-8 text-yellow-500" />;
                  badgeColor = "bg-yellow-100 border-yellow-300";
                  break;
                case 2:
                  badgeIcon = <Award className="h-8 w-8 text-gray-400" />;
                  badgeColor = "bg-gray-100 border-gray-300";
                  break;
                case 3:
                  badgeIcon = <Award className="h-8 w-8 text-amber-700" />;
                  badgeColor = "bg-amber-100 border-amber-300";
                  break;
                default:
                  badgeIcon = <Star className="h-8 w-8 text-primary" />;
                  badgeColor = "bg-primary-light border-primary";
              }
              
              const height = rank === 1 ? "h-60" : rank === 2 ? "h-52" : "h-44";
              
              return (
                <div 
                  key={user.id}
                  className={`flex-1 max-w-xs fade-in ${height} flex flex-col justify-end`}
                >
                  <div className={`card border-t-4 ${badgeColor} text-center relative`}>
                    <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 bg-white rounded-full p-2 shadow-lg">
                      {badgeIcon}
                    </div>
                    <div className="mt-4 pt-4">
                      <h3 className="font-bold text-xl text-gray-900 mt-2">{user.name}</h3>
                      <p className="text-gray-600 mb-2">Rank #{user.rank}</p>
                      <p className="text-primary font-bold text-2xl">{user.points} points</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          
          {restOfList.length > 0 && (
            <div className="card fade-in">
              <table className="w-full">
                <thead>
                  <tr className="text-left border-b border-gray-200">
                    <th className="pb-3 pl-4">Rank</th>
                    <th className="pb-3">Name</th>
                    <th className="pb-3 pr-4 text-right">Points</th>
                  </tr>
                </thead>
                <tbody>
                  {restOfList.map((user) => (
                    <tr key={user.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-4 pl-4 font-medium">{user.rank}</td>
                      <td className="py-4">{user.name}</td>
                      <td className="py-4 pr-4 text-right font-bold text-primary">{user.points}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default LeaderboardSection;
 
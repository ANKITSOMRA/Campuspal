import  { Mail, Phone, MapPin, Instagram, Facebook, Twitter } from 'lucide-react';

const ContactSection = () => {
  return (
    <section id="contact" className="py-20 bg-primary text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Get In Touch</h2>
          <p className="text-xl max-w-2xl mx-auto">
            Have questions about CampusPal or SRM University? Reach out to us.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-5xl mx-auto">
          <div className="fade-in">
            <h3 className="text-2xl font-bold mb-6">Contact Information</h3>
            
            <div className="space-y-6">
              <div className="flex items-start">
                <MapPin className="h-6 w-6 mr-3 mt-1" />
                <div>
                  <h4 className="font-semibold mb-1">Address</h4>
                  <p>SRM University, SRM Nagar, Kattankulathur, Tamil Nadu 603203</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <Mail className="h-6 w-6 mr-3 mt-1" />
                <div>
                  <h4 className="font-semibold mb-1">Email</h4>
                  <p>info@srmuniversity.ac.in</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <Phone className="h-6 w-6 mr-3 mt-1" />
                <div>
                  <h4 className="font-semibold mb-1">Phone</h4>
                  <p>+91 1800-123-4567</p>
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold mb-3">Follow SRM University</h4>
                <div className="flex space-x-4">
                  <a href="#" className="hover:text-white transition-colors duration-300" aria-label="Instagram">
                    <Instagram className="h-6 w-6" />
                  </a>
                  <a href="#" className="hover:text-white transition-colors duration-300" aria-label="Facebook">
                    <Facebook className="h-6 w-6" />
                  </a>
                  <a href="#" className="hover:text-white transition-colors duration-300" aria-label="Twitter">
                    <Twitter className="h-6 w-6" />
                  </a>
                </div>
              </div>
            </div>
          </div>
          
          <div className="fade-in">
            <h3 className="text-2xl font-bold mb-6">Send us a Message</h3>
            
            <form>
              <div className="mb-4">
                <label htmlFor="name" className="block mb-2 font-medium">Name</label>
                <input 
                  type="text" 
                  id="name" 
                  className="input-field text-gray-800"
                  placeholder="Your name" 
                />
              </div>
              
              <div className="mb-4">
                <label htmlFor="email" className="block mb-2 font-medium">Email</label>
                <input 
                  type="email" 
                  id="email" 
                  className="input-field text-gray-800"
                  placeholder="Your email" 
                />
              </div>
              
              <div className="mb-4">
                <label htmlFor="message" className="block mb-2 font-medium">Message</label>
                <textarea 
                  id="message" 
                  rows={4} 
                  className="input-field text-gray-800"
                  placeholder="Your message"
                ></textarea>
              </div>
              
              <button type="submit" className="btn bg-white text-primary hover:bg-gray-100 w-full">
                Send Message
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
 
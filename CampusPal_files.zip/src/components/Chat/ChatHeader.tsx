import  { ArrowLeft, Info } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const ChatHeader = () => {
  const navigate = useNavigate();

  return (
    <div className="bg-primary text-white p-4 flex items-center shadow-md">
      <button 
        onClick={() => navigate('/')}
        className="p-1 mr-3 rounded-full hover:bg-primary-dark transition-colors"
        aria-label="Go back"
      >
        <ArrowLeft className="h-6 w-6" />
      </button>
      
      <div className="flex-1">
        <h2 className="font-bold">CampusPal Assistant</h2>
        <p className="text-sm opacity-90">Online | SRM University</p>
      </div>
      
      <button 
        className="p-1 rounded-full hover:bg-primary-dark transition-colors"
        aria-label="Information"
      >
        <Info className="h-6 w-6" />
      </button>
    </div>
  );
};

export default ChatHeader;
 
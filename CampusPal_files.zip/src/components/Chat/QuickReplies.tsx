interface  QuickRepliesProps {
  onSelectReply: (reply: string) => void;
}

const QuickReplies: React.FC<QuickRepliesProps> = ({ onSelectReply }) => {
  const quickReplies = [
    "WiFi password?",
    "Where is the library?",
    "Exam schedule?",
    "Hostel information",
    "Campus map",
    "Upcoming events"
  ];

  return (
    <div className="p-4 bg-gray-100 border-t border-gray-200">
      <p className="text-gray-700 font-medium mb-2">Suggested questions:</p>
      <div className="flex flex-wrap gap-2">
        {quickReplies.map((reply, index) => (
          <button
            key={index}
            onClick={() => onSelectReply(reply)}
            className="bg-white border border-gray-300 rounded-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-primary transition-colors"
          >
            {reply}
          </button>
        ))}
      </div>
    </div>
  );
};

export default QuickReplies;
 
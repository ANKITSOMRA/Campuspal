import  { ChatMessage } from '../../types';
import { User, MessageSquare } from 'lucide-react';

interface MessageProps {
  message: ChatMessage;
}

const Message: React.FC<MessageProps> = ({ message }) => {
  const formattedTime = message.timestamp.toLocaleTimeString([], { 
    hour: '2-digit', 
    minute: '2-digit'
  });

  return (
    <div className={`flex ${message.isUser ? 'justify-end' : 'justify-start'} mb-4`}>
      {!message.isUser && (
        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-primary flex items-center justify-center mr-3">
          <MessageSquare className="h-5 w-5 text-white" />
        </div>
      )}
      
      <div className={`max-w-xs md:max-w-md lg:max-w-lg ${
        message.isUser 
          ? 'bg-primary text-white rounded-tl-xl rounded-bl-xl rounded-br-xl' 
          : 'bg-gray-100 text-gray-800 rounded-tr-xl rounded-br-xl rounded-bl-xl'
      } px-4 py-3 shadow`}>
        <p>{message.text}</p>
        <p className={`text-xs mt-1 ${message.isUser ? 'text-blue-100' : 'text-gray-500'} text-right`}>
          {formattedTime}
        </p>
      </div>
      
      {message.isUser && (
        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center ml-3">
          <User className="h-5 w-5 text-gray-600" />
        </div>
      )}
    </div>
  );
};

export default Message;
 
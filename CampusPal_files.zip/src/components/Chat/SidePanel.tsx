import  { useState } from 'react';
import { Map, Calendar, Book, Bell, User, X } from 'lucide-react';
import { events, locations, courses } from '../../data';

interface SidePanelProps {
  isOpen: boolean;
  onClose: () => void;
}

const SidePanel: React.FC<SidePanelProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState('map');

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    };
    return new Date(dateString).toLocaleDateString('en-US', options);
  };

  return (
    <div className={`fixed inset-y-0 right-0 w-80 bg-white shadow-xl transform transition-transform duration-300 z-20 ${
      isOpen ? 'translate-x-0' : 'translate-x-full'
    }`}>
      <div className="flex items-center justify-between p-4 border-b">
        <h3 className="font-bold text-lg">Campus Resources</h3>
        <button 
          onClick={onClose}
          className="text-gray-500 hover:text-gray-700"
          aria-label="Close panel"
        >
          <X className="h-5 w-5" />
        </button>
      </div>
      
      <div className="flex border-b">
        <button 
          onClick={() => setActiveTab('map')}
          className={`flex-1 py-3 px-4 text-center ${
            activeTab === 'map' ? 'text-primary border-b-2 border-primary' : 'text-gray-600'
          }`}
        >
          <Map className="h-5 w-5 mx-auto mb-1" />
          <span className="text-xs">Map</span>
        </button>
        
        <button 
          onClick={() => setActiveTab('events')}
          className={`flex-1 py-3 px-4 text-center ${
            activeTab === 'events' ? 'text-primary border-b-2 border-primary' : 'text-gray-600'
          }`}
        >
          <Calendar className="h-5 w-5 mx-auto mb-1" />
          <span className="text-xs">Events</span>
        </button>
        
        <button 
          onClick={() => setActiveTab('courses')}
          className={`flex-1 py-3 px-4 text-center ${
            activeTab === 'courses' ? 'text-primary border-b-2 border-primary' : 'text-gray-600'
          }`}
        >
          <Book className="h-5 w-5 mx-auto mb-1" />
          <span className="text-xs">Courses</span>
        </button>
        
        <button 
          onClick={() => setActiveTab('profile')}
          className={`flex-1 py-3 px-4 text-center ${
            activeTab === 'profile' ? 'text-primary border-b-2 border-primary' : 'text-gray-600'
          }`}
        >
          <User className="h-5 w-5 mx-auto mb-1" />
          <span className="text-xs">Profile</span>
        </button>
      </div>
      
      <div className="overflow-y-auto h-[calc(100%-116px)]">
        {activeTab === 'map' && (
          <div className="p-4">
            <h4 className="font-semibold mb-3">Campus Locations</h4>
            {locations.map((location) => (
              <div key={location.id} className="mb-4 p-3 border rounded-lg hover:bg-gray-50">
                <h5 className="font-medium text-gray-800">{location.name}</h5>
                <p className="text-sm text-gray-600 mb-2">{location.description}</p>
                <p className="text-xs text-gray-500">
                  <span className="font-semibold">Directions:</span> {location.directions}
                </p>
              </div>
            ))}
          </div>
        )}
        
        {activeTab === 'events' && (
          <div className="p-4">
            <h4 className="font-semibold mb-3">Upcoming Events</h4>
            {events.map((event) => (
              <div key={event.id} className="mb-4 p-3 border rounded-lg hover:bg-gray-50">
                <h5 className="font-medium text-gray-800">{event.title}</h5>
                <p className="text-sm text-primary mb-1">{formatDate(event.date)}</p>
                <p className="text-sm text-gray-600 mb-2">{event.description}</p>
                <p className="text-xs text-gray-500">
                  <span className="font-semibold">Location:</span> {event.location}
                </p>
              </div>
            ))}
          </div>
        )}
        
        {activeTab === 'courses' && (
          <div className="p-4">
            <h4 className="font-semibold mb-3">Course Schedule</h4>
            {courses.map((course) => (
              <div key={course.id} className="mb-4 p-3 border rounded-lg hover:bg-gray-50">
                <h5 className="font-medium text-gray-800">{course.name}</h5>
                <p className="text-xs text-primary mb-2">Code: {course.code}</p>
                <div className="text-sm">
                  <p className="font-medium text-gray-700 mb-1">Schedule:</p>
                  {course.schedule.map((session, index) => (
                    <div key={index} className="mb-1 text-gray-600">
                      <p className="text-xs">
                        <span className="font-semibold">{session.day}:</span> {session.time}
                      </p>
                      <p className="text-xs text-gray-500">{session.room}</p>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
        
        {activeTab === 'profile' && (
          <div className="p-4">
            <div className="flex justify-center mb-6">
              <div className="h-24 w-24 bg-primary rounded-full flex items-center justify-center">
                <User className="h-12 w-12 text-white" />
              </div>
            </div>
            
            <h4 className="text-xl font-semibold text-center mb-4">Student Profile</h4>
            
            <div className="space-y-4">
              <div className="p-3 border rounded-lg">
                <p className="text-sm text-gray-500">Name</p>
                <p className="font-medium">Demo Student</p>
              </div>
              
              <div className="p-3 border rounded-lg">
                <p className="text-sm text-gray-500">Student ID</p>
                <p className="font-medium">SRM12345678</p>
              </div>
              
              <div className="p-3 border rounded-lg">
                <p className="text-sm text-gray-500">Program</p>
                <p className="font-medium">B.Tech Computer Science</p>
              </div>
              
              <div className="p-3 border rounded-lg">
                <p className="text-sm text-gray-500">Semester</p>
                <p className="font-medium">5th Semester</p>
              </div>
              
              <div className="p-3 border rounded-lg flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Notifications</p>
                  <p className="font-medium">Enabled</p>
                </div>
                <Bell className="h-5 w-5 text-primary" />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SidePanel;
 
import  { useState } from 'react';
import { ChevronLeft, ChevronRight, User } from 'lucide-react';
import { testimonials } from '../data';

const TestimonialsSection = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  const nextTestimonial = () => {
    setActiveIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setActiveIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section id="testimonials" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">What Students Say</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Hear from SRM University students who use CampusPal every day.
          </p>
        </div>
        
        <div className="max-w-4xl mx-auto fade-in">
          <div className="relative overflow-hidden">
            <div className="flex transition-transform duration-500" style={{ transform: `translateX(-${activeIndex * 100}%)` }}>
              {testimonials.map((testimonial, index) => (
                <div key={index} className="min-w-full">
                  <div className="card text-center p-8">
                    <div className="mb-6 mx-auto bg-primary rounded-full w-20 h-20 flex items-center justify-center">
                      {testimonial.avatar ? (
                        <img 
                          src={testimonial.avatar} 
                          alt={testimonial.name} 
                          className="rounded-full w-full h-full object-cover"
                        />
                      ) : (
                        <User className="h-10 w-10 text-white" />
                      )}
                    </div>
                    <p className="text-gray-700 text-lg italic mb-6">"{testimonial.message}"</p>
                    <h4 className="font-bold text-gray-900">{testimonial.name}</h4>
                    <p className="text-gray-600">{testimonial.program}, {testimonial.year}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <button 
              onClick={prevTestimonial} 
              className="absolute left-0 top-1/2 transform -translate-y-1/2 -translate-x-1 bg-white rounded-full p-2 shadow-lg hover:bg-gray-100 focus:outline-none"
              aria-label="Previous testimonial"
            >
              <ChevronLeft className="h-6 w-6 text-primary" />
            </button>
            
            <button 
              onClick={nextTestimonial} 
              className="absolute right-0 top-1/2 transform -translate-y-1/2 translate-x-1 bg-white rounded-full p-2 shadow-lg hover:bg-gray-100 focus:outline-none"
              aria-label="Next testimonial"
            >
              <ChevronRight className="h-6 w-6 text-primary" />
            </button>
          </div>
          
          <div className="flex justify-center mt-6">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setActiveIndex(index)}
                className={`h-3 w-3 mx-1.5 rounded-full ${
                  index === activeIndex ? 'bg-primary' : 'bg-gray-300'
                }`}
                aria-label={`Go to testimonial ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
 
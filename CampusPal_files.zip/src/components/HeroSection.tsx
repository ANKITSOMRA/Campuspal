import  { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { MessageSquare } from 'lucide-react';

const HeroSection = () => {
  const typingTextRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    const element = typingTextRef.current;
    if (element) {
      element.classList.add('typing-text');
    }
  }, []);

  return (
    <div className="relative min-h-screen flex items-center justify-center animated-gradient overflow-hidden">
      <div className="absolute inset-0 bg-black opacity-40"></div>
      <div className="container mx-auto px-4 z-10 text-center">
        <div className="max-w-3xl mx-auto">
          <div className="mb-8">
            <MessageSquare className="h-16 w-16 text-white mx-auto mb-4" />
          </div>
          <div className="typing-container mb-6">
            <h1 ref={typingTextRef} className="text-4xl md:text-6xl font-bold text-white">
              Welcome to CampusPal – Your SRM University Assistant!
            </h1>
          </div>
          <p className="text-xl md:text-2xl text-white mb-8">
            Get instant answers about campus life, events, and resources
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/login" className="btn btn-primary">
              Get Started
            </Link>
            <a href="#features" className="btn bg-white text-primary hover:bg-gray-100">
              Learn More
            </a>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-8 left-0 right-0 text-center">
        <a 
          href="#features" 
          className="text-white animate-bounce inline-block"
          aria-label="Scroll down"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 14l-7 7m0 0l-7-7m7 7V3"></path>
          </svg>
        </a>
      </div>
    </div>
  );
};

export default HeroSection;
 
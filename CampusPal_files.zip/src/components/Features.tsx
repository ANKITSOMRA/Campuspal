import  { MessageSquare, Map, Calendar, User, Bell, Wifi } from 'lucide-react';

const Features = () => {
  const features = [
    {
      icon: <MessageSquare className="h-8 w-8 text-primary" />,
      title: "Instant Answers",
      description: "Get immediate responses to common questions about SRM University campus, facilities, and services."
    },
    {
      icon: <Map className="h-8 w-8 text-primary" />,
      title: "Campus Navigation",
      description: "Find your way around SRM University with easy directions to buildings, classrooms, and facilities."
    },
    {
      icon: <Calendar className="h-8 w-8 text-primary" />,
      title: "Event Updates",
      description: "Stay informed about upcoming campus events, workshops, festivals, and academic deadlines."
    },
    {
      icon: <User className="h-8 w-8 text-primary" />,
      title: "Personalized Experience",
      description: "Receive tailored information based on your program, year, and preferences."
    },
    {
      icon: <Bell className="h-8 w-8 text-primary" />,
      title: "Notifications",
      description: "Get timely alerts about important announcements, classes, and deadlines."
    },
    {
      icon: <Wifi className="h-8 w-8 text-primary" />,
      title: "24/7 Availability",
      description: "Access information anytime, anywhere, even when administrative offices are closed."
    }
  ];

  return (
    <section id="features" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">Why Students Love CampusPal</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Our AI assistant makes campus life easier by providing instant information and support tailored to SRM University.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="card hover:shadow-2xl fade-in"
            >
              <div className="mb-4">{feature.icon}</div>
              <h3 className="text-xl font-bold mb-2 text-gray-800">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
 
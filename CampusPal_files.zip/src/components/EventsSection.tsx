import  { Calendar } from 'lucide-react';
import { events } from '../data';

const EventsSection = () => {
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    };
    return new Date(dateString).toLocaleDateString('en-US', options);
  };
  
  const calculateDaysRemaining = (dateString: string) => {
    const eventDate = new Date(dateString);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const diffTime = eventDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays;
  };

  return (
    <section id="events" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">Upcoming Campus Events</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Stay updated with the latest events and activities at SRM University.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {events.map((event) => {
            const daysRemaining = calculateDaysRemaining(event.date);
            
            return (
              <div 
                key={event.id}
                className="card hover:shadow-2xl overflow-hidden fade-in"
              >
                {event.image && (
                  <div className="h-48 overflow-hidden">
                    <img 
                      src={event.image} 
                      alt={event.title} 
                      className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                    />
                  </div>
                )}
                
                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center text-primary">
                      <Calendar className="h-5 w-5 mr-2" />
                      <span>{formatDate(event.date)}</span>
                    </div>
                    
                    {daysRemaining > 0 && (
                      <span className="text-sm font-semibold bg-primary-light bg-opacity-20 text-primary-dark px-3 py-1 rounded-full">
                        {daysRemaining} days left
                      </span>
                    )}
                  </div>
                  
                  <h3 className="text-xl font-bold mb-2 text-gray-800">{event.title}</h3>
                  <p className="text-gray-600 mb-4">{event.description}</p>
                  <p className="text-gray-700 font-medium">
                    <span className="font-bold">Location:</span> {event.location}
                  </p>
                  
                  <button className="mt-4 btn btn-primary w-full">
                    Register Now
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default EventsSection;
 
import  { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, MessageSquare } from 'lucide-react';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navbarClass = scrolled 
    ? 'fixed w-full bg-primary shadow-lg transition-all duration-300 z-50'
    : 'fixed w-full bg-transparent transition-all duration-300 z-50';

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className={navbarClass}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Link to="/" className="flex items-center">
                <MessageSquare className="h-8 w-8 text-white" />
                <span className="ml-2 text-xl font-bold text-white">CampusPal</span>
              </Link>
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                <Link to="/" className={isActive('/') ? 'nav-link-active' : 'nav-link'}>Home</Link>
                <a href="#features" className="nav-link">Features</a>
                <a href="#how-it-works" className="nav-link">How It Works</a>
                <a href="#testimonials" className="nav-link">Testimonials</a>
                <a href="#events" className="nav-link">Events</a>
                <a href="#contact" className="nav-link">Contact</a>
              </div>
            </div>
          </div>
          <div className="hidden md:block">
            <Link to="/login" className="btn btn-secondary">
              Login
            </Link>
          </div>
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-white hover:text-white focus:outline-none"
            >
              {isOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden bg-primary">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <Link 
              to="/" 
              className={isActive('/') ? 'nav-link-active block' : 'nav-link block'}
              onClick={() => setIsOpen(false)}
            >
              Home
            </Link>
            <a href="#features" className="nav-link block" onClick={() => setIsOpen(false)}>Features</a>
            <a href="#how-it-works" className="nav-link block" onClick={() => setIsOpen(false)}>How It Works</a>
            <a href="#testimonials" className="nav-link block" onClick={() => setIsOpen(false)}>Testimonials</a>
            <a href="#events" className="nav-link block" onClick={() => setIsOpen(false)}>Events</a>
            <a href="#contact" className="nav-link block" onClick={() => setIsOpen(false)}>Contact</a>
          </div>
          <div className="pt-4 pb-3 border-t border-gray-700">
            <div className="px-2">
              <Link 
                to="/login" 
                className="block btn btn-secondary w-full text-center"
                onClick={() => setIsOpen(false)}
              >
                Login
              </Link>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
 
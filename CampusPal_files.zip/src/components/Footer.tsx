import  { Link } from 'react-router-dom';
import { MessageSquare } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <Link to="/" className="flex items-center mb-4">
              <MessageSquare className="h-8 w-8 text-white" />
              <span className="ml-2 text-xl font-bold">CampusPal</span>
            </Link>
            <p className="text-gray-400 mb-4">
              Your personal AI assistant for SRM University campus life and resources.
            </p>
          </div>
          
          <div>
            <h5 className="text-lg font-semibold mb-4">Quick Links</h5>
            <ul className="space-y-2">
              <li><Link to="/" className="text-gray-400 hover:text-white transition-colors duration-300">Home</Link></li>
              <li><a href="#features" className="text-gray-400 hover:text-white transition-colors duration-300">Features</a></li>
              <li><a href="#events" className="text-gray-400 hover:text-white transition-colors duration-300">Events</a></li>
              <li><Link to="/login" className="text-gray-400 hover:text-white transition-colors duration-300">Login</Link></li>
            </ul>
          </div>
          
          <div>
            <h5 className="text-lg font-semibold mb-4">Resources</h5>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors duration-300">SRM Official Website</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors duration-300">Student Portal</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors duration-300">Library Resources</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors duration-300">Career Services</a></li>
            </ul>
          </div>
          
          <div>
            <h5 className="text-lg font-semibold mb-4">Contact</h5>
            <ul className="space-y-2">
              <li className="text-gray-400">SRM University, Tamil Nadu</li>
              <li className="text-gray-400">info@srmuniversity.ac.in</li>
              <li className="text-gray-400">+91 1800-123-4567</li>
            </ul>
          </div>
        </div>
        
        <hr className="my-8 border-gray-800" />
        
        <div className="flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400">
            &copy; {currentYear} CampusPal. All rights reserved.
          </p>
          <div className="mt-4 md:mt-0">
            <ul className="flex space-x-4">
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors duration-300">Privacy Policy</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors duration-300">Terms of Service</a></li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
 